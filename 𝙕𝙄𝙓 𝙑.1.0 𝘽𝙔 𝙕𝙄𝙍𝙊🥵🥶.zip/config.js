require("./lib/module")

// SETTING KONTAK
global.owner = "6288287194884"
global.ownername = "𝙯𝙞𝙧𝙤𝘿𝙂"
global.nomorbot = "6285379559923"
global.namaCreator = "𝙯𝙞𝙧𝙤𝘿𝙂"
global.Dec = "𝙯𝙞𝙧𝙤𝘿𝙀𝙑"
global.autoJoin = false
global.antilink = false

// THUMBNAIL (BEBAS GANTI)
global.imageurl = 'https://img100.pixhost.to/images/928/543631871_skyzopedia.jpg'
global.channel = 'https://whatsapp.com/channel/0029Vah7UiG2kNFpDa73Rw0B'

// STICKER
global.packname = "𝐒𝐭𝐢𝐜𝐤𝐞𝐫 𝐁𝐲"
global.author = "𝙊𝙉𝙇𝙔 𝘿𝙂𝙯𝙞𝙧𝙤"
global.jumlah = "5"


















// RESPON BOT
global.onlyprem = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘱𝘳𝘦𝘮𝘪𝘶𝘮*`
global.onlyown = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘰𝘸𝘯𝘦𝘳*`
global.onlygroup = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘥𝘪 𝘨𝘳𝘶𝘱*`
global.onlyadmin = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘊𝘰𝘮𝘮𝘢𝘯𝘥 𝘬𝘩𝘶𝘴𝘶𝘴 𝘢𝘥𝘮𝘪𝘯*`
global.notext = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘔𝘢𝘯𝘢 𝘵𝘦𝘬𝘴𝘯𝘺𝘢*`
global.noadmin = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘉𝘰𝘵 𝘣𝘦𝘭𝘶𝘮 𝘮𝘦𝘯𝘫𝘢𝘥𝘪 𝘢𝘥𝘮𝘪𝘯*`
global.succes = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘋𝘰𝘯𝘦 𝘣𝘢𝘯𝘨 𝘥𝘪𝘬*`
global.invalid = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘔𝘢𝘴𝘶𝘬𝘬𝘢𝘯 𝘯𝘰𝘮𝘰𝘳 𝘺𝘢𝘯𝘨 𝘷𝘢𝘭𝘪𝘥*`
global.bugrespon = `\`[ # ] 👾⃟𒆜𝐒𝐈𝐗 𝐄𝐗𝐄 𝟔𝟔×⃟⚡\` \n*𝘛𝘶𝘯𝘨𝘨𝘶 𝘩𝘪𝘯𝘨𝘨𝘢 𝘣𝘰𝘵 𝘳𝘦𝘢𝘤𝘵 𝘦𝘮𝘰𝘫𝘪 ✅*`

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})